# Taco12 - A keyboard designed by PsychicTaco13
Website - https://tacokb.com/
Contact me on discord PsychicTaco13#6409 or on reddit u/r2d5198

Here you can find the build guide in PDF and .doc format as well as qmk files.
